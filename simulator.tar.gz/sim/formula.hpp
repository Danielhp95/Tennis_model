double _TBpq(double p, double q);
double TB(double p1, double p2);
double G(double p);
double _Spq(double p, double q);
double S(double p1, double p2);
double _M3pq(double p, double q);
double M3(double p1, double p2);
double _M5pq(double p, double q);
double M5(double p1, double p2);

